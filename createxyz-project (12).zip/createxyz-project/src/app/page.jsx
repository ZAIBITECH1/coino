"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading } = useUser();
  const [transactions, setTransactions] = useState([]);
  const [coinos, setCoinos] = useState(0);
  const [taps, setTaps] = useState(0);
  const [energy, setEnergy] = useState(500);
  const [multiplier, setMultiplier] = useState(1);
  const [referralCount, setReferralCount] = useState(0);
  const [showStats, setShowStats] = useState(false);
  const [lastRegenTime, setLastRegenTime] = useState(Date.now());
  const [streak, setStreak] = useState(0);
  const [lastMineTime, setLastMineTime] = useState(null);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [showShop, setShowShop] = useState(false);
  const [powerups, setPowerups] = useState([]);
  const [achievements, setAchievements] = useState([]);
  const [showAchievements, setShowAchievements] = useState(false);
  const [dailyQuest, setDailyQuest] = useState(null);
  const [questProgress, setQuestProgress] = useState(0);
  const [showMiningGame, setShowMiningGame] = useState(false);
  const [gameScore, setGameScore] = useState(0);
  const maxEnergy = 500;
  const regenRate = 1;
  const regenInterval = 60000;

  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      const timePassed = now - lastRegenTime;
      const energyToAdd = Math.floor(timePassed / regenInterval) * regenRate;

      if (energyToAdd > 0) {
        setEnergy((prev) => Math.min(maxEnergy, prev + energyToAdd));
        setLastRegenTime(now);
      }
    }, regenInterval);
    return () => clearInterval(timer);
  }, [lastRegenTime]);

  useEffect(() => {
    if (user?.id) {
      fetch("/api/db/database-3298044", {
        method: "POST",
        body: JSON.stringify({
          query: "SELECT * FROM `users` WHERE `id` = ?",
          values: [user.id],
        }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data && data.length > 0) {
            const userData = data[0];
            setCoinos(userData.balance || 0);
            setStreak(userData.streak || 0);
            setReferralCount(userData.referral_count || 0);
            setLastMineTime(userData.last_mine || null);
          } else {
            fetch("/api/db/database-3298044", {
              method: "POST",
              body: JSON.stringify({
                query:
                  "INSERT INTO `users` (`id`, `streak`, `balance`, `last_mine`, `referral_count`) VALUES (?, ?, ?, ?, ?)",
                values: [user.id, 0, 0, null, 0],
              }),
            });
          }
        });

      fetch("/api/db/transactions-7137164", {
        method: "POST",
        body: JSON.stringify({
          query:
            "SELECT * FROM `mining_transactions` WHERE `user_id` = ? ORDER BY `timestamp` DESC LIMIT 10",
          values: [user.id],
        }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (Array.isArray(data)) {
            setTransactions(data);
          }
        });
    }
  }, [user]);

  useEffect(() => {
    if (user?.id && coinos > 0) {
      fetch("/api/db/database-3298044", {
        method: "POST",
        body: JSON.stringify({
          query:
            "UPDATE `users` SET `balance` = ?, `last_mine` = ?, `streak` = ? WHERE `id` = ?",
          values: [coinos, lastMineTime, streak, user.id],
        }),
      });
    }
  }, [coinos, lastMineTime, streak, user?.id]);

  useEffect(() => {
    const now = Date.now();
    if (lastMineTime) {
      const timeDiff = now - lastMineTime;
      if (timeDiff < 3600000) {
        setStreak((prev) => Math.min(prev + 1, 10));
      } else {
        setStreak(0);
      }
    }
    setLastMineTime(now);
  }, [taps]);

  const handleBoost = useCallback(() => {
    if (energy > 0) {
      const bonus = 1 + streak * 0.1;
      const amount = 0.1 * multiplier * bonus;
      setCoinos((prev) => prev + amount);
      setTaps((prev) => prev + 1);
      setEnergy((prev) => Math.max(0, prev - 1));

      if (user?.id) {
        const newTransaction = {
          user_id: user.id,
          amount,
          timestamp: new Date().toISOString(),
        };

        fetch("/api/db/transactions-7137164", {
          method: "POST",
          body: JSON.stringify({
            query:
              "INSERT INTO `mining_transactions` (`user_id`, `amount`, `timestamp`) VALUES (?, ?, ?)",
            values: [user.id, amount, newTransaction.timestamp],
          }),
        });

        setTransactions((prev) => [newTransaction, ...prev.slice(0, 9)]);
      }
    }
  }, [energy, multiplier, streak, user?.id]);
  const referralLink = `https://t.me/your_bot?start=${user?.id}`;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#1a1a1a] flex items-center justify-center">
        <div className="text-[#FFD700] text-2xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#1a1a1a] text-white p-4 pb-24 md:pb-4">
      <div className="fixed top-0 left-0 right-0 bg-[#2a2a2a] p-2 text-center text-sm">
        <a
          href="https://coino.pages.dev"
          className="text-[#FFD700] hover:underline"
        >
          coino.pages.dev
        </a>
      </div>
      <div className="flex justify-between items-center mb-4 md:mb-8">
        <h1 className="text-[#FFD700] text-2xl md:text-3xl font-bold">
          Mine Coino
        </h1>
        <div className="flex gap-2 md:gap-4">
          <button onClick={() => setShowStats(!showStats)} className="p-2">
            <i className="fas fa-chart-bar text-xl md:text-2xl text-white"></i>
          </button>
          <button
            onClick={() => navigator.clipboard.writeText(referralLink)}
            className="p-2"
          >
            <i className="fas fa-share text-xl md:text-2xl text-white"></i>
          </button>
        </div>
      </div>
      <div className="bg-[#2a2a2a] rounded-lg p-4 md:p-6 mb-4 md:mb-8">
        <div className="flex flex-col gap-2 mb-4">
          <div className="flex justify-between text-lg md:text-2xl">
            <div>💰 Coinos: {coinos.toFixed(2)}</div>
            <div>👆 Taps: {taps}</div>
          </div>
          <div className="flex justify-between text-sm md:text-base">
            <div>
              ⚡ Energy: {energy}/{maxEnergy}
            </div>
            <div>🔥 Multiplier: x{multiplier}</div>
          </div>
          <div className="flex justify-between text-sm md:text-base">
            <div>👥 Referrals: {referralCount}</div>
            <div>🎯 Streak: x{(1 + streak * 0.1).toFixed(1)}</div>
          </div>
        </div>

        <button
          onClick={handleBoost}
          disabled={energy <= 0}
          className="w-full bg-gradient-to-r from-[#FFD700] to-[#FFA500] text-black py-3 md:py-4 rounded-lg font-bold flex items-center justify-center gap-2 disabled:opacity-50 text-lg md:text-xl shadow-lg transform active:scale-95 transition-transform"
        >
          <i className="fas fa-bolt"></i>
          Mine Coino {streak > 0 ? `(+${streak * 10}% Bonus)` : ""}
        </button>
      </div>
      <div className="bg-[#2a2a2a] rounded-lg p-4 md:p-6 mb-4 md:mb-8">
        <h2 className="text-lg md:text-xl font-bold mb-4">
          Recent Transactions
        </h2>
        <div className="space-y-2">
          {transactions?.map((tx, i) => (
            <div
              key={i}
              className="flex justify-between items-center text-sm md:text-base"
            >
              <div>+{tx.amount.toFixed(2)} COINO</div>
              <div className="text-xs md:text-sm text-gray-400">
                {new Date(tx.timestamp).toLocaleTimeString()}
              </div>
            </div>
          ))}
        </div>
      </div>

      {showStats && (
        <div className="bg-[#2a2a2a] rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Mining Stats</h2>
          <div className="space-y-2">
            <div>Total Mined: {coinos.toFixed(2)} COINO</div>
            <div>Base Mining Rate: {(0.1 * multiplier).toFixed(2)}/tap</div>
            <div>Streak Bonus: +{streak * 10}%</div>
            <div>
              Energy Regeneration: {regenRate} every {regenInterval / 1000}s
            </div>
            <div>Total Transactions: {transactions?.length || 0}</div>
            <div>
              Average Mining Rate:{" "}
              {transactions?.length > 0
                ? (
                    transactions.reduce((acc, tx) => acc + tx.amount, 0) /
                    transactions.length
                  ).toFixed(2)
                : "0.00"}
              /tap
            </div>
          </div>
        </div>
      )}

      {showLeaderboard && (
        <div className="bg-[#2a2a2a] rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Top Miners</h2>
          <div className="space-y-4">
            {leaderboardData.map((player, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[#FFD700]">#{index + 1}</span>
                  <span>{player.name}</span>
                </div>
                <span>{player.coinos} COINO</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {showShop && (
        <div className="bg-[#2a2a2a] rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Power-up Shop</h2>
          <div className="grid grid-cols-2 gap-4">
            {powerups.map((powerup, index) => (
              <div key={index} className="bg-[#3a3a3a] p-4 rounded-lg">
                <div className="text-lg font-bold">{powerup.name}</div>
                <div className="text-sm text-gray-400">
                  {powerup.description}
                </div>
                <button className="mt-2 bg-[#FFD700] text-black px-4 py-2 rounded-lg">
                  Buy for {powerup.price} COINO
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {showAchievements && (
        <div className="bg-[#2a2a2a] rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Achievements</h2>
          <div className="grid grid-cols-2 gap-4">
            {achievements.map((achievement, index) => (
              <div key={index} className="bg-[#3a3a3a] p-4 rounded-lg">
                <div className="text-lg font-bold">{achievement.name}</div>
                <div className="text-sm text-gray-400">
                  {achievement.description}
                </div>
                <div className="mt-2 h-2 bg-[#1a1a1a] rounded-full">
                  <div
                    className="h-full bg-[#FFD700] rounded-full"
                    style={{
                      width: `${
                        (achievement.progress / achievement.target) * 100
                      }%`,
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {dailyQuest && (
        <div className="bg-[#2a2a2a] rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Daily Quest</h2>
          <div className="bg-[#3a3a3a] p-4 rounded-lg">
            <div className="text-lg font-bold">{dailyQuest.title}</div>
            <div className="text-sm text-gray-400">
              {dailyQuest.description}
            </div>
            <div className="mt-2 h-2 bg-[#1a1a1a] rounded-full">
              <div
                className="h-full bg-[#FFD700] rounded-full"
                style={{
                  width: `${(questProgress / dailyQuest.target) * 100}%`,
                }}
              ></div>
            </div>
            <div className="mt-2 text-sm">
              Progress: {questProgress}/{dailyQuest.target}
            </div>
          </div>
        </div>
      )}

      {showMiningGame && (
        <div className="bg-[#2a2a2a] rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Mining Game</h2>
          <div className="bg-[#3a3a3a] p-4 rounded-lg text-center">
            <div className="text-3xl font-bold mb-4">{gameScore}</div>
            <button className="bg-[#FFD700] text-black px-6 py-3 rounded-lg">
              Play Mini-Game
            </button>
          </div>
        </div>
      )}

      <div className="bg-gradient-to-r from-[#FFD700] to-[#FFA500] w-32 h-32 md:w-48 md:h-48 rounded-full mx-auto flex items-center justify-center animate-pulse">
        <i className="fas fa-coins text-4xl md:text-6xl text-black"></i>
      </div>
      <div className="fixed bottom-0 left-0 right-0 bg-[#2a2a2a] p-2 md:p-4">
        <div className="flex justify-between max-w-md mx-auto">
          <button
            onClick={() => setShowMiningGame(!showMiningGame)}
            className="text-[#FFD700] p-2"
          >
            <i className="fas fa-gamepad text-xl md:text-2xl"></i>
          </button>
          <button
            onClick={() => setShowLeaderboard(!showLeaderboard)}
            className="p-2"
          >
            <i className="fas fa-trophy text-xl md:text-2xl text-white"></i>
          </button>
          <button onClick={() => setShowShop(!showShop)} className="p-2">
            <i className="fas fa-store text-xl md:text-2xl text-white"></i>
          </button>
          <button
            onClick={() => setShowAchievements(!showAchievements)}
            className="p-2"
          >
            <i className="fas fa-medal text-xl md:text-2xl text-white"></i>
          </button>
          <button onClick={() => window.location.reload()} className="p-2">
            <i className="fas fa-sync text-xl md:text-2xl text-white"></i>
          </button>
        </div>
      </div>
      <style jsx global>{`
        @keyframes pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }
        .animate-pulse {
          animation: pulse 2s infinite;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;